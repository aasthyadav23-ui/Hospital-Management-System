import 'package:flutter/material.dart';

class PatientDetailScreen extends StatelessWidget {
  final Map<String, dynamic> data; // Ye data receive karega

  const PatientDetailScreen({super.key, required this.data});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Patient Full Details"),
        backgroundColor: Colors.teal,
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header with Icon
            Center(
              child: CircleAvatar(
                radius: 40,
                backgroundColor: Colors.teal.shade100,
                child: const Icon(Icons.person, size: 50, color: Colors.teal),
              ),
            ),
            const SizedBox(height: 20),

            // Details Card
            Card(
              elevation: 4,
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  children: [
                    _buildRow("Name", data['name'] ?? data['patient_name'] ?? 'N/A'),
                    const Divider(),
                    _buildRow("Age", data['age'] ?? 'N/A'),
                    const Divider(),
                    _buildRow("Phone", data['phone'] ?? 'N/A'),
                    const Divider(),
                    _buildRow("Gender", data['gender'] ?? 'N/A'),
                    const Divider(),
                    _buildRow("Doctor", data['doctor'] ?? 'N/A'),
                    const Divider(),
                    _buildRow("Date", data['date'] ?? 'N/A'),
                    const Divider(),
                    _buildRow("Time", data['time'] ?? 'N/A'),
                    const Divider(),
                    _buildRow("Status", data['status'] ?? 'N/A'),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Helper Widget for Rows
  Widget _buildRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: const TextStyle(fontWeight: FontWeight.bold, color: Colors.grey)),
          Text(value, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
        ],
      ),
    );
  }
}