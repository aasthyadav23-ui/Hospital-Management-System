import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../doctor_data.dart';

class BillingScreen extends StatefulWidget {
  const BillingScreen({super.key});
  @override
  State<BillingScreen> createState() => _BillingScreenState();
}

class _BillingScreenState extends State<BillingScreen> {
  Doctor _selectedDoctor = hospitalDoctors[0];
  final TextEditingController _nameController = TextEditingController();
  String _paymentMode = "Cash";
  bool _isPaymentDone = false;

  Future<void> _fakePayment() async {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (c) => const Center(child: CircularProgressIndicator(color: Colors.white)),
    );

    await Future.delayed(const Duration(seconds: 2));

    Navigator.pop(context);

    ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text("Payment Received Successfully! ✅"),
          backgroundColor: Colors.green,
          duration: Duration(seconds: 2),
        )
    );

    setState(() {
      _isPaymentDone = true;
    });
  }

  Future<void> _saveBill() async {
    if (_nameController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Please Enter Patient Name")));
      return;
    }

    if (_paymentMode == "Online" && !_isPaymentDone) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("⚠️ Please Complete Payment First!"), backgroundColor: Colors.orange));
      return;
    }

    DateTime now = DateTime.now();
    String todayDate = "${now.day}/${now.month}/${now.year}";

    await FirebaseFirestore.instance.collection('bills').add({
      'name': _nameController.text,
      'amount': _selectedDoctor.fee,
      'doctor': _selectedDoctor.name,
      'mode': _paymentMode,
      'date': todayDate,
      'timestamp': FieldValue.serverTimestamp()
    });

    showDialog(context: context, builder: (c) => AlertDialog(
      title: const Text("Bill Saved ✅", style: TextStyle(color: Colors.green)),
      content: Text("Patient: ${_nameController.text}\nAmount: ₹${_selectedDoctor.fee}"),
      actions: [TextButton(onPressed: () => Navigator.pop(c), child: const Text("OK"))],
    ));

    _nameController.clear();
    setState(() {
      _paymentMode = "Cash";
      _isPaymentDone = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Billing Counter"), backgroundColor: Colors.purple),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text("New Invoice", style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
              const SizedBox(height: 20),

              TextField(controller: _nameController, decoration: const InputDecoration(labelText: "Patient Name", border: OutlineInputBorder(), prefixIcon: Icon(Icons.person))),
              const SizedBox(height: 20),

              DropdownButtonFormField<Doctor>(
                value: _selectedDoctor,
                items: hospitalDoctors.map((e) => DropdownMenuItem(value: e, child: Text(e.name))).toList(),
                onChanged: (v) => setState(() => _selectedDoctor = v!),
                decoration: const InputDecoration(labelText: "Select Doctor", border: OutlineInputBorder()),
              ),
              const SizedBox(height: 20),

              const Text("Payment Mode:", style: TextStyle(fontWeight: FontWeight.bold)),
              Row(
                children: [
                  Expanded(child: RadioListTile(title: const Text("Cash 💵"), value: "Cash", groupValue: _paymentMode, activeColor: Colors.green, onChanged: (v) => setState(() => _paymentMode = v!))),
                  Expanded(child: RadioListTile(title: const Text("Online 📱"), value: "Online", groupValue: _paymentMode, activeColor: Colors.purple, onChanged: (v) => setState(() => _paymentMode = v!))),
                ],
              ),

              const SizedBox(height: 20),

              Card(
                color: Colors.purple.shade50,
                child: Padding(
                  padding: const EdgeInsets.all(20.0),
                  child: Center(child: Text("Total: ₹${_selectedDoctor.fee}", style: const TextStyle(fontSize: 30, fontWeight: FontWeight.bold, color: Colors.purple))),
                ),
              ),

              const SizedBox(height: 30),

              if (_paymentMode == "Online")
                SizedBox(
                  width: double.infinity,
                  height: 50,
                  child: ElevatedButton.icon(
                    icon: _isPaymentDone ? const Icon(Icons.check_circle) : const Icon(Icons.payment),
                    label: Text(_isPaymentDone ? "PAYMENT DONE" : "PAY NOW (Demo)", style: const TextStyle(fontSize: 18)),
                    style: ElevatedButton.styleFrom(backgroundColor: _isPaymentDone ? Colors.green : Colors.indigo, foregroundColor: Colors.white),
                    onPressed: _isPaymentDone ? null : _fakePayment,
                  ),
                ),

              const SizedBox(height: 15),

              SizedBox(
                width: double.infinity,
                height: 50,
                child: ElevatedButton(
                  onPressed: _saveBill,
                  style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
                  child: const Text("SAVE BILL", style: TextStyle(color: Colors.white, fontSize: 18)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}