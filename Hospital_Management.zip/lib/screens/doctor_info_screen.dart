import 'package:flutter/material.dart';
import '../doctor_data.dart'; // Doctor Data Import

class DoctorInfoScreen extends StatelessWidget {
  const DoctorInfoScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Doctor Details & Timing"), backgroundColor: Colors.teal),
      body: ListView.builder(
        itemCount: hospitalDoctors.length,
        itemBuilder: (context, index) {
          final doc = hospitalDoctors[index];
          return Card(
            margin: const EdgeInsets.all(10),
            elevation: 4,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Header: Name & Fee
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(doc.name, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.teal)),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                        decoration: BoxDecoration(color: Colors.green.shade100, borderRadius: BorderRadius.circular(10)),
                        child: Text("Fees: ₹${doc.fee}", style: const TextStyle(fontWeight: FontWeight.bold, color: Colors.green)),
                      ),
                    ],
                  ),
                  const SizedBox(height: 5),
                  Text(doc.department, style: const TextStyle(color: Colors.grey, fontStyle: FontStyle.italic)),
                  const Divider(),

                  // Details
                  _buildInfoRow(Icons.access_time, "Timing:", doc.timing),
                  _buildInfoRow(Icons.location_on, "Clinic:", doc.clinicAddr),
                  _buildInfoRow(Icons.phone, "Contact:", doc.phone),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildInfoRow(IconData icon, String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Row(
        children: [
          Icon(icon, size: 20, color: Colors.teal.shade300),
          const SizedBox(width: 10),
          Text(label, style: const TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(width: 5),
          Expanded(child: Text(value)),
        ],
      ),
    );
  }
}