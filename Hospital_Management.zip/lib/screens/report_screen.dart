import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../doctor_data.dart';

class ReportScreen extends StatelessWidget {
  const ReportScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Hospital Report & Receipts"), backgroundColor: Colors.indigo),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text("Hospital Summary", style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
              const SizedBox(height: 10),

              Row(
                children: [
                  Expanded(child: _buildStatCard("Total Patients", Colors.blue, 'patients')),
                  const SizedBox(width: 10),
                  Expanded(child: _buildStatCard("Appointments", Colors.orange, 'appointments')),
                ],
              ),

              const SizedBox(height: 25),
              const Divider(thickness: 2),
              const SizedBox(height: 10),

              const Text("Generate Receipts", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              const SizedBox(height: 10),

              StreamBuilder<QuerySnapshot>(
                stream: FirebaseFirestore.instance.collection('patients').orderBy('timestamp', descending: true).limit(10).snapshots(),
                builder: (context, snapshot) {
                  if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());

                  var docs = snapshot.data!.docs;

                  return ListView.builder(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    itemCount: docs.length,
                    itemBuilder: (context, index) {
                      var data = docs[index].data() as Map<String, dynamic>;
                      return Card(
                        child: ListTile(
                          leading: const Icon(Icons.receipt_long, color: Colors.indigo),
                          title: Text(data['name'] ?? 'Unknown', style: const TextStyle(fontWeight: FontWeight.bold)),
                          subtitle: Text("Dr. ${data['doctor']}"),
                          trailing: ElevatedButton.icon(
                            icon: const Icon(Icons.print, size: 16),
                            label: const Text("Receipt"),
                            style: ElevatedButton.styleFrom(backgroundColor: Colors.indigo, foregroundColor: Colors.white),
                            onPressed: () {
                              _showReceiptDialog(context, data);
                            },
                          ),
                        ),
                      );
                    },
                  );
                },
              )
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildStatCard(String title, Color color, String collection) {
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance.collection(collection).snapshots(),
      builder: (context, snapshot) {
        String count = snapshot.hasData ? "${snapshot.data!.docs.length}" : "...";
        return Container(
          padding: const EdgeInsets.all(15),
          decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(10)),
          child: Column(
            children: [
              Text(count, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Colors.white)),
              Text(title, style: const TextStyle(color: Colors.white)),
            ],
          ),
        );
      },
    );
  }

  // 🧾 NEW: Database se Hospital Info laayega
  void _showReceiptDialog(BuildContext context, Map<String, dynamic> patientData) {
    // Pehle Hospital Data fetch karo, fir Dialog dikhao
    FirebaseFirestore.instance.collection('settings').doc('hospital_profile').get().then((docSnapshot) {

      Map<String, dynamic> hospitalData = docSnapshot.exists
          ? (docSnapshot.data() as Map<String, dynamic>)
          : {'name': 'City Hospital', 'phone': 'Not Available'};

      String docName = patientData['doctor'];
      int fees = 500;
      try {
        fees = hospitalDoctors.firstWhere((d) => d.name == docName).fee;
      } catch (e) {
        fees = 500;
      }

      showDialog(
        context: context,
        builder: (ctx) => AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
          title: Column(
            children: [
              const Icon(Icons.local_hospital, color: Colors.indigo, size: 40),
              const SizedBox(height: 5),
              // ✅ Dynamic Hospital Name
              Text(hospitalData['name'].toString().toUpperCase(), textAlign: TextAlign.center, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
              const SizedBox(height: 5),
              const Text("OPD RECEIPT", style: TextStyle(fontSize: 12, letterSpacing: 2, color: Colors.grey)),
            ],
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Divider(thickness: 2),
              _receiptRow("Patient Name:", patientData['name']),
              _receiptRow("Age / Gender:", "${patientData['age']} / ${patientData['gender']}"),
              _receiptRow("Date:", patientData['date'] ?? 'Today'),
              const Divider(),
              _receiptRow("Consultant:", docName),
              _receiptRow("Fees Paid:", "₹ $fees"),
              const Divider(thickness: 2),

              const SizedBox(height: 10),
              const Text("✅ PAiD", style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Colors.green, letterSpacing: 2)),
              const SizedBox(height: 5),

              // ✅ Dynamic Helpline Number
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(color: Colors.grey.shade100, borderRadius: BorderRadius.circular(5)),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Icon(Icons.phone, size: 16, color: Colors.indigo),
                    const SizedBox(width: 5),
                    Text("Helpline: ${hospitalData['phone']}", style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
                  ],
                ),
              ),
              const SizedBox(height: 5),
              const Text("Get well soon!", style: TextStyle(fontSize: 10, color: Colors.grey)),
            ],
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx), child: const Text("CLOSE")),
            ElevatedButton(onPressed: () => Navigator.pop(ctx), child: const Text("PRINT")),
          ],
        ),
      );
    });
  }

  Widget _receiptRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: const TextStyle(color: Colors.grey, fontWeight: FontWeight.bold, fontSize: 12)),
          Text(value, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
        ],
      ),
    );
  }
}