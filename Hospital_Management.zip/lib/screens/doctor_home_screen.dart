import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../doctor_data.dart';

class DoctorHomeScreen extends StatefulWidget {
  const DoctorHomeScreen({super.key});

  @override
  State<DoctorHomeScreen> createState() => _DoctorHomeScreenState();
}

class _DoctorHomeScreenState extends State<DoctorHomeScreen> {
  // Default Doctor Select
  String selectedDoctorName = hospitalDoctors[0].name;

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2, // 2 Tabs: OPD aur Appointments
      child: Scaffold(
        appBar: AppBar(
          title: const Text("Doctor Dashboard"),
          backgroundColor: Colors.redAccent,
          bottom: const TabBar(
            indicatorColor: Colors.white,
            tabs: [
              Tab(icon: Icon(Icons.people), text: "OPD Queue (Walk-in)"),
              Tab(icon: Icon(Icons.phone), text: "Phone Appointments"),
            ],
          ),
        ),
        body: Column(
          children: [
            // Doctor Selector (Main uppar rahega)
            Container(
              padding: const EdgeInsets.all(15),
              color: Colors.redAccent.withOpacity(0.1),
              child: Row(
                children: [
                  const Text("Doctor Profile: ", style: TextStyle(fontWeight: FontWeight.bold)),
                  const SizedBox(width: 10),
                  Expanded(
                    child: DropdownButton<String>(
                      value: selectedDoctorName,
                      isExpanded: true,
                      items: hospitalDoctors.map((d) => DropdownMenuItem(value: d.name, child: Text(d.name))).toList(),
                      onChanged: (v) => setState(() => selectedDoctorName = v!),
                    ),
                  ),
                ],
              ),
            ),

            // Tab Views
            Expanded(
              child: TabBarView(
                children: [
                  // Tab 1: OPD Patients List
                  _buildPatientList('patients'),

                  // Tab 2: Phone Appointments List
                  _buildPatientList('appointments'),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Common Widget to fetch List
  Widget _buildPatientList(String collectionName) {
    return StreamBuilder<QuerySnapshot>(
      // Filter: Sirf wahi patients dikhao jo 'waiting' hain aur Isi Doctor ke hain
      stream: FirebaseFirestore.instance
          .collection(collectionName)
          .where('doctor', isEqualTo: selectedDoctorName)
      //.where('status', isEqualTo: 'waiting') // Agar aap chahein to sirf waiting dikhayein
          .snapshots(),
      builder: (context, snapshot) {
        if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());

        var docs = snapshot.data!.docs;

        if (docs.isEmpty) {
          return Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(Icons.inbox, size: 50, color: Colors.grey),
                const SizedBox(height: 10),
                Text("No patients found in $collectionName"),
              ],
            ),
          );
        }

        return ListView.builder(
          itemCount: docs.length,
          itemBuilder: (context, index) {
            var data = docs[index].data() as Map<String, dynamic>;
            String docId = docs[index].id;

            // Name field kabhi 'name' hai kabhi 'patient_name', usko handle karte hain
            String name = data['name'] ?? data['patient_name'] ?? 'Unknown';
            String status = data['status'] ?? 'Unknown';

            return Card(
              margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
              child: ListTile(
                leading: CircleAvatar(
                  backgroundColor: status == 'Completed' ? Colors.green : Colors.redAccent,
                  child: status == 'Completed'
                      ? const Icon(Icons.check, color: Colors.white)
                      : Text(name[0].toUpperCase(), style: const TextStyle(color: Colors.white)),
                ),
                title: Text(name, style: const TextStyle(fontWeight: FontWeight.bold)),
                subtitle: Text("Status: $status"),
                trailing: status == 'waiting' || status == 'Scheduled'
                    ? ElevatedButton(
                  style: ElevatedButton.styleFrom(backgroundColor: Colors.green, padding: const EdgeInsets.symmetric(horizontal: 10)),
                  onPressed: () {
                    // Mark as Completed
                    FirebaseFirestore.instance.collection(collectionName).doc(docId).update({'status': 'Completed'});
                  },
                  child: const Text("Done", style: TextStyle(fontSize: 12)),
                )
                    : const Text("Visited", style: TextStyle(color: Colors.grey)),
              ),
            );
          },
        );
      },
    );
  }
}