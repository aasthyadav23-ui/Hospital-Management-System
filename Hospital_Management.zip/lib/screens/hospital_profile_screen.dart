import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class HospitalProfileScreen extends StatelessWidget {
  const HospitalProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.teal.shade50,
      appBar: AppBar(title: const Text("Hospital Profile"), backgroundColor: Colors.teal),

      // ✅ Ab Data Firebase se aayega
      body: StreamBuilder<DocumentSnapshot>(
        stream: FirebaseFirestore.instance.collection('settings').doc('hospital_profile').snapshots(),
        builder: (context, snapshot) {
          // Loading State
          if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());

          // Agar data nahi mila
          if (!snapshot.data!.exists) {
            return const Center(child: Text("No Profile Found. Please Setup first."));
          }

          // Data nikalna
          var data = snapshot.data!.data() as Map<String, dynamic>;

          return SingleChildScrollView(
            child: Column(
              children: [
                // 1. Big Header
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(40),
                  decoration: const BoxDecoration(
                    color: Colors.teal,
                    borderRadius: BorderRadius.only(bottomLeft: Radius.circular(30), bottomRight: Radius.circular(30)),
                  ),
                  child: Column(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(15),
                        decoration: const BoxDecoration(color: Colors.white, shape: BoxShape.circle),
                        child: const Icon(Icons.local_hospital, size: 60, color: Colors.teal),
                      ),
                      const SizedBox(height: 15),
                      Text(
                        data['name'] ?? "Hospital Name",
                        textAlign: TextAlign.center,
                        style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: Colors.white),
                      ),
                      Text(
                        "Established 1998", // Ye fix rakh sakte hain ya DB mein add kar sakte hain
                        style: TextStyle(color: Colors.teal.shade100),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 20),

                // 2. Info Cards
                Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    children: [
                      _buildProfileCard(Icons.location_on, "Address", data['address'] ?? "Not Set"),
                      _buildProfileCard(Icons.phone, "Reception / Enquiry", data['phone'] ?? "Not Set"),
                      _buildProfileCard(Icons.email, "Email Address", data['email'] ?? "Not Set"),

                      // Emergency Card (Fixed)
                      Card(
                        elevation: 4,
                        color: Colors.red.shade50,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
                        margin: const EdgeInsets.only(bottom: 15),
                        child: const ListTile(
                          leading: CircleAvatar(backgroundColor: Colors.red, child: Icon(Icons.emergency, color: Colors.white)),
                          title: Text("Emergency Number", style: TextStyle(color: Colors.grey, fontSize: 12)),
                          subtitle: Text("108 / 102", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.red)),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  Widget _buildProfileCard(IconData icon, String title, String value) {
    return Card(
      elevation: 3,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      margin: const EdgeInsets.only(bottom: 15),
      child: ListTile(
        leading: CircleAvatar(backgroundColor: Colors.teal.withOpacity(0.1), child: Icon(icon, color: Colors.teal)),
        title: Text(title, style: const TextStyle(color: Colors.grey, fontSize: 12)),
        subtitle: Text(value, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
      ),
    );
  }
}