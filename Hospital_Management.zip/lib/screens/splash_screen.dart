import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'login_screen.dart';
import 'setup_hospital_screen.dart'; // Next step mein banayenge

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    _checkSetup();
  }

  // Database check karna
  Future<void> _checkSetup() async {
    // 2 Second ka wait taaki Logo dikhe
    await Future.delayed(const Duration(seconds: 2));

    // Check karo ki settings save hain ya nahi
    var doc = await FirebaseFirestore.instance.collection('settings').doc('hospital_profile').get();

    if (doc.exists) {
      // Setup pehle se hai -> Login par bhejo
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => const LoginScreen()));
    } else {
      // Naya User hai -> Setup par bhejo
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => const SetupHospitalScreen()));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.teal,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(20),
              decoration: const BoxDecoration(color: Colors.white, shape: BoxShape.circle),
              child: const Icon(Icons.local_hospital, size: 80, color: Colors.teal),
            ),
            const SizedBox(height: 20),
            const Text("Hospital Management", style: TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            const CircularProgressIndicator(color: Colors.white),
          ],
        ),
      ),
    );
  }
}