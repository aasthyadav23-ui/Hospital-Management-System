import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'login_screen.dart';

class SetupHospitalScreen extends StatefulWidget {
  const SetupHospitalScreen({super.key});

  @override
  State<SetupHospitalScreen> createState() => _SetupHospitalScreenState();
}

class _SetupHospitalScreenState extends State<SetupHospitalScreen> {
  final _nameController = TextEditingController();
  final _addressController = TextEditingController();
  final _phoneController = TextEditingController();
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();

  bool _isLoading = false;

  Future<void> _saveDetails() async {
    if (_nameController.text.isEmpty || _passwordController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Name and Password are required!")));
      return;
    }

    setState(() => _isLoading = true);

    // ✅ Database mein data save karna
    await FirebaseFirestore.instance.collection('settings').doc('hospital_profile').set({
      'name': _nameController.text,
      'address': _addressController.text,
      'phone': _phoneController.text,
      'email': _emailController.text,
      'password': _passwordController.text, // Ye password Login mein use hoga
    });

    setState(() => _isLoading = false);

    // Login Screen par bhejo
    Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => const LoginScreen()));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Setup Hospital Profile"), backgroundColor: Colors.teal),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            children: [
              const Icon(Icons.add_business, size: 80, color: Colors.teal),
              const SizedBox(height: 20),
              const Text("Create Admin Account", style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
              const Text("Enter your hospital details below", style: TextStyle(color: Colors.grey)),
              const SizedBox(height: 30),

              TextField(controller: _nameController, decoration: const InputDecoration(labelText: "Hospital Name", border: OutlineInputBorder(), prefixIcon: Icon(Icons.local_hospital))),
              const SizedBox(height: 15),
              TextField(controller: _addressController, decoration: const InputDecoration(labelText: "Full Address", border: OutlineInputBorder(), prefixIcon: Icon(Icons.location_on))),
              const SizedBox(height: 15),
              TextField(controller: _phoneController, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: "Helpline Number", border: OutlineInputBorder(), prefixIcon: Icon(Icons.phone))),
              const SizedBox(height: 15),
              TextField(controller: _emailController, decoration: const InputDecoration(labelText: "Email ID", border: OutlineInputBorder(), prefixIcon: Icon(Icons.email))),
              const SizedBox(height: 15),
              TextField(controller: _passwordController, obscureText: true, decoration: const InputDecoration(labelText: "Set Admin Password", border: OutlineInputBorder(), prefixIcon: Icon(Icons.lock))),

              const SizedBox(height: 30),
              SizedBox(
                width: double.infinity,
                height: 50,
                child: ElevatedButton(
                  onPressed: _isLoading ? null : _saveDetails,
                  style: ElevatedButton.styleFrom(backgroundColor: Colors.teal),
                  child: _isLoading ? const CircularProgressIndicator(color: Colors.white) : const Text("CREATE ACCOUNT", style: TextStyle(color: Colors.white, fontSize: 18)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}