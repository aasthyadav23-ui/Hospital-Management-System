import 'package:flutter/material.dart';
// Purane Imports
import 'patient_screen.dart';
import 'appointment_screen.dart';
import 'billing_screen.dart';
import 'all_patients_screen.dart';
import 'report_screen.dart';
import 'doctor_home_screen.dart';
import 'doctor_info_screen.dart';

// ✅ Naya Import (Hospital Profile Screen)
import 'hospital_profile_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[100],
      appBar: AppBar(
        title: const Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text("Welcome, Receptionist 👋", style: TextStyle(fontSize: 18)),
            Text("Hospital Management Dashboard", style: TextStyle(fontSize: 12)),
          ],
        ),
        backgroundColor: Colors.teal,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: GridView.count(
          crossAxisCount: 2, // Ek line mein 2 buttons
          crossAxisSpacing: 15,
          mainAxisSpacing: 15,
          children: [
            // 1. OPD Register
            _buildCard(context, "OPD Register", Icons.person_add, Colors.blue, const PatientScreen()),

            // 2. Appointments
            _buildCard(context, "Appointments", Icons.phone_in_talk, Colors.orange, const AppointmentScreen()),

            // 3. Billing
            _buildCard(context, "Billing", Icons.receipt_long, Colors.purple, const BillingScreen()),

            // 4. Patient List (Search)
            _buildCard(context, "Patient Records", Icons.search, Colors.brown, const AllPatientsScreen()),

            // 5. Daily Report
            _buildCard(context, "Daily Report", Icons.bar_chart, Colors.green, const ReportScreen()),

            // 6. Doctor View
            _buildCard(context, "Doctor View", Icons.medical_services, Colors.redAccent, const DoctorHomeScreen()),

            // 7. Doctors Info
            _buildCard(context, "Doctors Info", Icons.info_outline, Colors.teal, const DoctorInfoScreen()),

            // 8. Hospital Profile ✅ ADDED NEW
            _buildCard(context, "Hospital Profile", Icons.local_hospital, Colors.indigo, const HospitalProfileScreen()),
          ],
        ),
      ),
    );
  }

  // Helper Widget (Card Design)
  Widget _buildCard(BuildContext context, String title, IconData icon, Color color, Widget? page) {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      child: InkWell(
        onTap: () {
          if (page != null) {
            Navigator.push(context, MaterialPageRoute(builder: (context) => page));
          } else {
            ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Feature Coming Soon!")));
          }
        },
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CircleAvatar(
                radius: 30,
                backgroundColor: color.withOpacity(0.1),
                child: Icon(icon, size: 30, color: color)
            ),
            const SizedBox(height: 10),
            Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
          ],
        ),
      ),
    );
  }
}