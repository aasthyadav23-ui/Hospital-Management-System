import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../doctor_data.dart'; // Doctor List Import

class PatientScreen extends StatefulWidget {
  const PatientScreen({super.key});

  @override
  State<PatientScreen> createState() => _PatientScreenState();
}

class _PatientScreenState extends State<PatientScreen> {
  // Controllers
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _ageController = TextEditingController();
  final TextEditingController _phoneController = TextEditingController();

  // Selections
  String _selectedDoctorName = hospitalDoctors[0].name; // Sirf naam store karenge
  String _selectedGender = "Male";

  // 📅 Date & Time Variables (Default = Abhi ka waqt)
  DateTime _selectedDate = DateTime.now();
  TimeOfDay _selectedTime = TimeOfDay.now();

  bool _isLoading = false;

  // Helper Function: Current Selected Doctor ka poora data nikalo
  Doctor getSelectedDoctorDetails() {
    return hospitalDoctors.firstWhere((doc) => doc.name == _selectedDoctorName);
  }

  // Function: Date Choose karne ke liye
  Future<void> _pickDate() async {
    DateTime? picked = await showDatePicker(
      context: context,
      initialDate: _selectedDate,
      firstDate: DateTime(2000),
      lastDate: DateTime(2100),
    );
    if (picked != null) setState(() => _selectedDate = picked);
  }

  // Function: Time Choose karne ke liye
  Future<void> _pickTime() async {
    TimeOfDay? picked = await showTimePicker(
      context: context,
      initialTime: _selectedTime,
    );
    if (picked != null) setState(() => _selectedTime = picked);
  }

  // Save Data to Firebase
  Future<void> _register() async {
    if (_nameController.text.isEmpty || _ageController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("⚠️ Name and Age required!")));
      return;
    }

    setState(() => _isLoading = true);

    String dateText = "${_selectedDate.day}/${_selectedDate.month}/${_selectedDate.year}";
    String timeText = _selectedTime.format(context);

    try {
      await FirebaseFirestore.instance.collection('patients').add({
        'name': _nameController.text,
        'age': _ageController.text,
        'gender': _selectedGender,
        'phone': _phoneController.text,
        'doctor': _selectedDoctorName,
        'date': dateText,
        'time': timeText,
        'status': 'waiting',
        'timestamp': FieldValue.serverTimestamp(),
      });

      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("✅ Patient Registered Successfully!")));

      _nameController.clear();
      _ageController.clear();
      _phoneController.clear();
      setState(() {
        _selectedDate = DateTime.now();
        _selectedTime = TimeOfDay.now();
      });

    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Error: $e")));
    } finally {
      setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    // Current Doctor ki details nikaali taaki display kar sakein
    Doctor currentDoctor = getSelectedDoctorDetails();

    return Scaffold(
      appBar: AppBar(title: const Text("OPD Registration"), backgroundColor: Colors.blue),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // 1. Personal Info
              const Text("Personal Details", style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
              const SizedBox(height: 10),
              TextField(controller: _nameController, decoration: const InputDecoration(labelText: "Patient Name", prefixIcon: Icon(Icons.person), border: OutlineInputBorder())),
              const SizedBox(height: 10),
              Row(
                children: [
                  Expanded(child: TextField(controller: _ageController, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: "Age", prefixIcon: Icon(Icons.calendar_today), border: OutlineInputBorder()))),
                  const SizedBox(width: 10),
                  Expanded(
                    child: DropdownButtonFormField(
                      value: _selectedGender,
                      items: ["Male", "Female", "Other"].map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
                      onChanged: (v) => setState(() => _selectedGender = v as String),
                      decoration: const InputDecoration(labelText: "Gender", border: OutlineInputBorder()),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              TextField(controller: _phoneController, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: "Phone Number", prefixIcon: Icon(Icons.phone), border: OutlineInputBorder())),

              const SizedBox(height: 20),
              const Divider(thickness: 1),
              const SizedBox(height: 10),

              // 2. Doctor Info & TIMING (Updated)
              const Text("Assign Doctor", style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
              const SizedBox(height: 10),

              DropdownButtonFormField(
                value: _selectedDoctorName,
                isExpanded: true,
                items: hospitalDoctors.map((e) => DropdownMenuItem(value: e.name, child: Text(e.name))).toList(),
                onChanged: (v) {
                  setState(() {
                    _selectedDoctorName = v as String;
                  });
                },
                decoration: const InputDecoration(labelText: "Select Doctor", prefixIcon: Icon(Icons.medical_services), border: OutlineInputBorder()),
              ),

              const SizedBox(height: 10),

              // ✅ NEW: Auto-Show Doctor Timing
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.green.shade50, // Halkaa Green background
                  border: Border.all(color: Colors.green),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.access_time_filled, color: Colors.green),
                    const SizedBox(width: 10),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text("Available Time:", style: TextStyle(fontSize: 12, color: Colors.green.shade900)),
                        Text(
                          currentDoctor.timing, // Yahan Timing dikhegi
                          style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.green),
                        ),
                      ],
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 20),
              const Divider(thickness: 1),
              const SizedBox(height: 10),

              // 3. Visit Time
              const Text("Visit Entry Time", style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
              const SizedBox(height: 10),
              Row(
                children: [
                  Expanded(
                    child: InkWell(
                      onTap: _pickDate,
                      child: Container(
                        padding: const EdgeInsets.all(15),
                        decoration: BoxDecoration(border: Border.all(color: Colors.grey), borderRadius: BorderRadius.circular(5)),
                        child: Row(children: [const Icon(Icons.calendar_month, color: Colors.blue), const SizedBox(width: 8), Text("${_selectedDate.day}/${_selectedDate.month}/${_selectedDate.year}")]),
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: InkWell(
                      onTap: _pickTime,
                      child: Container(
                        padding: const EdgeInsets.all(15),
                        decoration: BoxDecoration(border: Border.all(color: Colors.grey), borderRadius: BorderRadius.circular(5)),
                        child: Row(children: [const Icon(Icons.access_time, color: Colors.blue), const SizedBox(width: 8), Text(_selectedTime.format(context))]),
                      ),
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 30),

              SizedBox(
                width: double.infinity,
                height: 50,
                child: ElevatedButton(
                  onPressed: _isLoading ? null : _register,
                  style: ElevatedButton.styleFrom(backgroundColor: Colors.blue),
                  child: _isLoading
                      ? const CircularProgressIndicator(color: Colors.white)
                      : const Text("REGISTER PATIENT", style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}