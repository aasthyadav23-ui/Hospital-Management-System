import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../doctor_data.dart'; // Doctor Data Import

class AppointmentScreen extends StatefulWidget {
  const AppointmentScreen({super.key});
  @override
  State<AppointmentScreen> createState() => _AppointmentScreenState();
}

class _AppointmentScreenState extends State<AppointmentScreen> {
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _phoneController = TextEditingController();

  // Default Doctor Select
  Doctor _selectedDoctor = hospitalDoctors[0];

  bool _isLoading = false;

  Future<void> _bookToken() async {
    if (_nameController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Please enter Patient Name")));
      return;
    }

    setState(() => _isLoading = true); // Loading Start

    try {
      // 1. Aaj ki Date Nikalo
      DateTime now = DateTime.now();
      String todayDate = "${now.day}/${now.month}/${now.year}";

      // 2. ✅ CORRECT TOKEN LOGIC
      // Database se pucho: "Aaj ka sabse bada token kaunsa hai?"
      QuerySnapshot lastTokenSnap = await FirebaseFirestore.instance
          .collection('appointments')
          .where('doctor', isEqualTo: _selectedDoctor.name)
          .where('date', isEqualTo: todayDate)
          .orderBy('token', descending: true) // Sabse bada number pehle
          .limit(1)
          .get();

      int newToken = 1; // Agar aaj koi patient nahi hai to 1 se shuru hoga

      if (lastTokenSnap.docs.isNotEmpty) {
        // Agar pehle se patient hain, to last token mein +1 jod do
        newToken = lastTokenSnap.docs.first['token'] + 1;
      }

      // 3. Save to Firebase
      await FirebaseFirestore.instance.collection('appointments').add({
        'token': newToken, // ✅ 1, 2, 3... Sahi number aayega
        'patient_name': _nameController.text,
        'phone': _phoneController.text,
        'doctor': _selectedDoctor.name,
        'date': todayDate,
        'status': 'Scheduled',
        'time': DateTime.now().toString(),
        'timestamp': FieldValue.serverTimestamp(),
      });

      // 4. Show Token Dialog (Popup)
      if (!mounted) return;
      showDialog(context: context, barrierDismissible: false, builder: (c) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
        title: const Center(child: Text("Booking Confirmed ✅", style: TextStyle(color: Colors.green))),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text("Your Token Number is", style: TextStyle(color: Colors.grey)),
            Text("#$newToken", style: TextStyle(fontSize: 50, fontWeight: FontWeight.bold, color: Colors.orange)),
            const Divider(),
            Text("Doctor: ${_selectedDoctor.name}", style: const TextStyle(fontWeight: FontWeight.bold)),
            Text("Time: ${_selectedDoctor.timing}", style: const TextStyle(color: Colors.grey)),
          ],
        ),
        actions: [
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
                style: ElevatedButton.styleFrom(backgroundColor: Colors.orange),
                onPressed: () {
                  Navigator.pop(c); // Popup band
                  Navigator.pop(context); // Wapas Home screen par
                  _nameController.clear();
                  _phoneController.clear();
                },
                child: const Text("OK, DONE", style: TextStyle(color: Colors.white))
            ),
          )
        ],
      ));
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Error: $e")));
    }

    setState(() => _isLoading = false); // Loading Stop
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Book Appointment"), backgroundColor: Colors.orange),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text("Patient Details", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              const SizedBox(height: 15),

              TextField(
                  controller: _nameController,
                  decoration: const InputDecoration(labelText: "Patient Name", prefixIcon: Icon(Icons.person), border: OutlineInputBorder())
              ),
              const SizedBox(height: 15),

              TextField(
                  controller: _phoneController,
                  keyboardType: TextInputType.phone,
                  decoration: const InputDecoration(labelText: "Mobile Number", prefixIcon: Icon(Icons.phone), border: OutlineInputBorder())
              ),

              const SizedBox(height: 25),
              const Divider(thickness: 2),
              const SizedBox(height: 10),

              const Text("Select Doctor", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              const SizedBox(height: 10),

              DropdownButtonFormField<Doctor>(
                value: _selectedDoctor,
                items: hospitalDoctors.map((e) => DropdownMenuItem(value: e, child: Text(e.name))).toList(),
                onChanged: (v) => setState(() => _selectedDoctor = v!),
                decoration: const InputDecoration(labelText: "Choose Doctor", border: OutlineInputBorder(), prefixIcon: Icon(Icons.medical_services)),
              ),

              const SizedBox(height: 15),

              // Doctor Timing Box
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(15),
                decoration: BoxDecoration(
                  color: Colors.orange.shade50,
                  border: Border.all(color: Colors.orange),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.access_time_filled, color: Colors.orange, size: 30),
                    const SizedBox(width: 15),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text("Doctor Available Time:", style: TextStyle(fontSize: 12, color: Colors.orange.shade900)),
                        Text(
                          _selectedDoctor.timing,
                          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.deepOrange),
                        ),
                      ],
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 40),

              SizedBox(
                width: double.infinity,
                height: 55,
                child: ElevatedButton(
                    onPressed: _isLoading ? null : _bookToken,
                    style: ElevatedButton.styleFrom(backgroundColor: Colors.orange, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
                    child: _isLoading
                        ? const CircularProgressIndicator(color: Colors.white)
                        : const Text("BOOK & GENERATE TOKEN", style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold))
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}