// File: lib/doctor_data.dart

class Doctor {
  final String name;
  final String specialist; // Purane code ke liye
  final String department; // Naye code ke liye
  final int fee;
  final String timing;
  final String clinicAddr;
  final String phone;

  Doctor({
    required this.name,
    required this.specialist,
    required this.department,
    required this.fee,
    required this.timing,
    required this.clinicAddr,
    required this.phone,
  });
}

// Doctors List
List<Doctor> hospitalDoctors = [
  Doctor(
    name: "Dr. Amit Sharma",
    specialist: "Cardiologist",
    department: "Heart Dept",
    fee: 800,
    timing: "10:00 AM - 02:00 PM",
    clinicAddr: "Room 101, City Hospital",
    phone: "+91 98765 43210",
  ),
  Doctor(
    name: "Dr. Priya Verma",
    specialist: "Pediatrician",
    department: "Child Care",
    fee: 500,
    timing: "04:00 PM - 08:00 PM",
    clinicAddr: "Room 205, City Hospital",
    phone: "+91 98123 45678",
  ),
  Doctor(
    name: "Dr. Rahul Gupta",
    specialist: "General Physician",
    department: "OPD",
    fee: 300,
    timing: "09:00 AM - 01:00 PM",
    clinicAddr: "OPD Ward, City Hospital",
    phone: "+91 99887 76655",
  ),
  Doctor(
    name: "Dr. Neha Singh",
    specialist: "Dentist",
    department: "Dental Care",
    fee: 400,
    timing: "05:00 PM - 09:00 PM",
    clinicAddr: "Dental Block, City Hospital",
    phone: "+91 91234 56789",
  ),
];