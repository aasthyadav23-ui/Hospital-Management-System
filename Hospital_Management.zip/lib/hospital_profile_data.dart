class HospitalInfo {
  // Yahan aap apne Hospital ki details edit kar sakti hain
  static const String name = "City Care General Hospital";
  static const String address = "Plot No. 45, Health Road, Near Metro Station, Mumbai - 400001";
  static const String phone = "+91 22 1234 5678";
  static const String email = "contact@citycarehospital.com";
  static const String website = "www.citycarehospital.com";
  static const String emergency = "108 / 102";
  static const String established = "Est. 1998";
}